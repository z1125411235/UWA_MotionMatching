﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum MotionMainEntryType
{
    none,
    stand,//站
    crouch,//蹲
    prone,//趴
}
